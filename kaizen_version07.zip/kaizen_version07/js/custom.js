  
//        $('.left').click(function(){
//            $('.wrapper').css({
//                left: '100%'
//            });
//        });
//        $('.right').hover(function(){
//            $('.wrapper').css({
//                left: '0%'
//            });
//        });
//        
//        $('.two').click(function(){
//            $(this).toggleClass('after');
//        });
        
        
//        $('h1').click(function(){
//            $(this).css({
//                color: 'red',
//                fontSize: '50px'
//            });
//        });
//        
//        $('.off').click(function(){
//            $('.wrapper').slideUp(500);
//        });
//        
//        $('.on').click(function(){
//            $('.wrapper').slideDown(500);
//        });
//        
//        $('.tg').click(function(){
//            $('.wrapper').slideToggle(500);
//        });
//        

//        $topOffset=300;
//        $('.top_to').click(function(){
//            $('html,body').animate({
//                scrollTop:0
//            },500);
//        });

        
        $topOffset=300;
        $('.top_to').click(function(){
            $('html,body').animate({
                scrollTop:0
            },500);
        });

        $navOffset=$('header').offset().top;
        
        $(window).scroll(function(){
            $scrolling=$(this).scrollTop();
            if($scrolling > $navOffset){
                $('header').addClass('menufixed');
            }
            else{
               $('header').removeClass('menufixed'); 
            }
        // top_to start
            if($scrolling > $topOffset){
               $('.top_to').fadeIn(); 
            }
            else{
                $('.top_to').fadeOut();
            }
            // top_to start
            if($scrolling > $topOffset){
               $('.top_to').fadeIn(); 
            }
            else{
                $('.top_to').fadeOut();
            }
        });

		













