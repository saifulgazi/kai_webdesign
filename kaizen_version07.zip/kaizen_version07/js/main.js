$(document).ready(function(){
    $('.venobox').venobox(); 
    
 $('.team-slide').slick({
  dots: false,
  autoplay:true,
  arrows:false,
  speed: 600,
  slidesToShow: 4,
  slidesToScroll: 2,
  responsive: [
    {
      breakpoint: 991,
      settings: {
        slidesToShow: 3,
        slidesToScroll: 1,
        infinite: true,
        dots: false,
      }
    },
    {
      breakpoint: 767,
      settings: {
        slidesToShow: 1,
        
      }
    },
    {
      breakpoint: 576,
      settings: {
        slidesToShow: 1,
      }
    }
    // You can unslick at a given breakpoint now by adding:
    // settings: "unslick"
    // instead of a settings object
  ]
});
    
    $('.testimonial-slide').slick({
  dots: false,
  autoplay:true,
  arrows:false,
  dots:false,
  speed: 600,
  slidesToShow: 2,
  slidesToScroll: 1,
  responsive: [
    {
      breakpoint: 991,
      settings: {
        slidesToShow: 1,
        slidesToScroll: 1,
        infinite: true,
        dots: true
      }
    },
    {
      breakpoint: 767,
      settings: {
        slidesToShow: 1,
        
      }
    },
    {
      breakpoint: 576,
      settings: {
        slidesToShow: 1,
      }
    }
    // You can unslick at a given breakpoint now by adding:
    // settings: "unslick"
    // instead of a settings object
  ]
});
    
    $('.client-slide').slick({
  dots: false,
  autoplay:true,
  arrows:false,
  speed: 600,
  slidesToShow: 5,
  slidesToScroll: 2,
        nextArrow:'<i class="fas fa-chevron-left left-arrow"></i>',
        prevArrow:'<i class="fas fa-chevron-right right-arrow"></i>',
        
        
  responsive: [
    {
      breakpoint: 991,
      settings: {
        slidesToShow: 3,
        slidesToScroll: 3,
        infinite: true,
        dots: false
      }
    },
    {
      breakpoint: 767,
      settings: {
        slidesToShow: 2,
        slidesToScroll: 2,
          arrows:false,
      }
    },
    {
      breakpoint: 575,
      settings: {
        slidesToShow: 2,
        slidesToScroll: 1,
          arrows:false,
      }
    }
    // You can unslick at a given breakpoint now by adding:
    // settings: "unslick"
    // instead of a settings object
  ]
});
     $('.partner-slide').slick({
  dots: false,
  autoplay:true,
  arrows:false,
  speed: 600,
  slidesToShow: 5,
  slidesToScroll: 2,
        nextArrow:'<i class="fas fa-chevron-left left-arrow"></i>',
        prevArrow:'<i class="fas fa-chevron-right right-arrow"></i>',
        
        
  responsive: [
    {
      breakpoint: 991,
      settings: {
        slidesToShow: 3,
        slidesToScroll: 3,
        infinite: true,
        dots: false
      }
    },
    {
      breakpoint: 767,
      settings: {
        slidesToShow: 2,
        slidesToScroll: 2,
          arrows:false,
      }
    },
    {
      breakpoint: 575,
      settings: {
        slidesToShow: 2,
        slidesToScroll: 1,
          arrows:false,
      }
    }
    // You can unslick at a given breakpoint now by adding:
    // settings: "unslick"
    // instead of a settings object
  ]
});
    
    $('.counter').counterUp({
    delay: 10,
    time: 1000
});
    
    jQuery(document).ready(function(){
    jQuery('#demo1').skdslider({
      slideSelector: '.slide',
      delay:5000,
      animationSpeed:2000,
      showNextPrev:true,
      showPlayButton:true,
      autoSlide:true,
      animationType:'fading'
    });

    jQuery('#demo2').skdslider({
      slideSelector: '.slide',
      delay:5000, 
      animationSpeed: 1000,
      showNextPrev:true,
      showPlayButton:false,
      autoSlide:true,
      animationType:'sliding'
    });
});

$(document).ready(function(){
  $('.venobox').venobox({
      spinner: 'wave'
  }); 
});
    
    wow = new WOW(
                      {
                      boxClass:     'wow',      // default
                      animateClass: 'animated', // default
                      offset:       0,          // default
                      mobile:       true,       // default
                      live:         true        // default
                    }
                    )
                    wow.init();
    
    
});